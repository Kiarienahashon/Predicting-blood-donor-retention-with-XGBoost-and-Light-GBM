#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import streamlit as st
import pandas as pd
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import lightgbm as lgb
from sklearn.ensemble import VotingClassifier
import numpy as np

# Load the dataset for scaler fitting (assuming the dataset has been split and saved for this purpose)
data = pd.read_csv('blooddonations3.csv')

# Drop only the 'Average Wait' column
data = data.drop(columns=['Average Wait'])

# Define features and target
X = data.drop(columns=['Donated Blood in 2024'])
y = data['Donated Blood in 2024']

# Select only the four features to be used for prediction
features = ['Age', 'Months Since Last Donation', 'Previous Donations', 'Months since First Donation']
X_selected = X[features]

# Normalize and scale the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_selected)

# Define the best parameters for XGBoost and LightGBM
best_params_xgb = {
    'colsample_bytree': 1.0,
    'learning_rate': 0.029838455200215885,
    'max_depth': 7,
    'min_child_weight': 1,
    'n_estimators': 500,
    'reg_alpha': 0.0,
    'reg_lambda': 10.0,
    'subsample': 0.9481224317229469
}

best_params_lgb = {
    'colsample_bytree': 0.8267148525436493,
    'learning_rate': 0.038245461647662224,
    'max_depth': 10,
    'min_child_weight': 1,
    'n_estimators': 230,
    'num_leaves': 20,
    'reg_alpha': 0.0,
    'reg_lambda': 0.0,
    'subsample': 0.6
}

# Train the XGBoost model
model_xgb = xgb.XGBClassifier(**best_params_xgb)
model_xgb.fit(X_scaled, y)

# Train the LightGBM model
model_lgb = lgb.LGBMClassifier(**best_params_lgb)
model_lgb.fit(X_scaled, y)

# Create the hybrid ensemble model using soft voting
ensemble_model = VotingClassifier(estimators=[
    ('xgb', model_xgb),
    ('lgb', model_lgb)
], voting='soft')

ensemble_model.fit(X_scaled, y)

# Streamlit interface
st.title('Blood Donation Prediction')

age = st.number_input('Age', min_value=0)
gender = st.selectbox('Gender', ['Male', 'Female'])
education = st.selectbox('Education Level', ['Primary', 'Secondary', 'Tertiary'])
months_since_last = st.number_input('Months Since Last Donation', min_value=0)
previous_donations = st.number_input('Previous Donations', min_value=0)
months_since_first = st.number_input('Months since First Donation', min_value=0)
donated_2024 = st.selectbox('Donated Blood in 2024', [0, 1])

# Only use the relevant features for prediction
input_data = pd.DataFrame([[
    age,
    months_since_last,
    previous_donations,
    months_since_first
]], columns=features)

input_data_scaled = scaler.transform(input_data)

# Predict using the ensemble model
prediction = ensemble_model.predict(input_data_scaled)
prediction_proba = ensemble_model.predict_proba(input_data_scaled)[:, 1]

if st.button('Predict'):
    st.write('Prediction: ', 'Likely to Return' if prediction[0] else 'Not Likely to Return')
    st.write('Probability of Returning: {:.4f}'.format(prediction_proba[0]))

